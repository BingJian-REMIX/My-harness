"""
文件操作技能：列出目录、读取文件、写入文件
"""

import os
from pathlib import Path

def execute(action, path, content=None):
    """
    action: 'list', 'read', 'write'
    path: 文件或目录路径
    content: 写入内容（仅 write 需要）
    """
    path = Path(path).resolve()
    if action == 'list':
        if not path.exists():
            return f"路径不存在: {path}"
        return "\n".join([str(p) for p in path.iterdir()])
    elif action == 'read':
        if not path.exists():
            return f"文件不存在: {path}"
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()[:5000]
    elif action == 'write':
        if not content:
            return "写入内容不能为空"
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        return f"文件已写入: {path}"
    else:
        return f"不支持的操作: {action}"